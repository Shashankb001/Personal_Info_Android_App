package com.example.da1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.da1.HelperClass.CityHC;
import com.example.da1.HelperClass.DegreeHC;
import com.example.da1.R;

import java.util.ArrayList;

public class CityListAdapter extends ArrayAdapter<CityHC> {

    private Context mContext;
    int mResource;

    public CityListAdapter(Context context, int resource, ArrayList<CityHC> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        int image = getItem(position).getImageID();
        String city = getItem(position).getCity();

        CityHC cityHC = new CityHC(image, city);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource, parent, false);

        ImageView img = (ImageView) convertView.findViewById(R.id.imageView1);
        TextView cit = (TextView) convertView.findViewById(R.id.city_inp);

        img.setImageResource(image);
        cit.setText(city);

        return convertView;
    }
}
