package com.example.da1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.da1.HelperClass.CHC;
import com.example.da1.HelperClass.DegreeHC;
import com.example.da1.R;

import java.util.ArrayList;

public class CListAdapter extends ArrayAdapter<CHC> {

    private Context mContext;
    int mResource;

    public CListAdapter(Context context, int resource, ArrayList<CHC> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String course = getItem(position).getCourse();
        String code = getItem(position).getCode();
        String year = getItem(position).getYear();

        CHC cHC = new CHC(course, code, year);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource, parent, false);

        TextView cs = (TextView) convertView.findViewById(R.id.course_inp);
        TextView cd = (TextView) convertView.findViewById(R.id.code_inp);
        TextView y = (TextView) convertView.findViewById(R.id.year_inp);

        cs.setText(course);
        cd.setText(code);
        y.setText(year);

        return convertView;
    }
}
