package com.example.da1.HelperClass;

public class CityHC {

    int imageID;
    String city;

    public CityHC(int imageID, String city) {
        this.imageID = imageID;
        this.city = city;
    }

    public int getImageID() {
        return imageID;
    }

    public void setImageID(int imageID) {
        this.imageID = imageID;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
