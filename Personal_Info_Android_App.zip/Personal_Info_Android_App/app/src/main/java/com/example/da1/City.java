package com.example.da1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.da1.Adapter.CityListAdapter;
import com.example.da1.Adapter.DegreeListAdapter;
import com.example.da1.HelperClass.CityHC;
import com.example.da1.HelperClass.DegreeHC;

import java.util.ArrayList;

public class City extends AppCompatActivity {

    ListView list;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city);

        //Getting title of the action bar
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");

        //Adding back button to action bar and setting title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(title);

        list = findViewById(R.id.list_city);

        CityHC c1 = new CityHC(R.drawable.pune, "Pune");
        CityHC c2 = new CityHC(R.drawable.hyderabad, "Hyderabad");
        CityHC c3 = new CityHC(R.drawable.nashik, "Nashik");
        CityHC c4 = new CityHC(R.drawable.srinagar, "Srinagar");
        CityHC c5 = new CityHC(R.drawable.mumbai, "Mumbai");


        ArrayList<CityHC> cityList = new ArrayList<>();
        cityList.add(c1);
        cityList.add(c2);
        cityList.add(c3);
        cityList.add(c4);
        cityList.add(c5);

        CityListAdapter adp = new CityListAdapter(this, R.layout.city_list, cityList);
        list.setAdapter(adp);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}