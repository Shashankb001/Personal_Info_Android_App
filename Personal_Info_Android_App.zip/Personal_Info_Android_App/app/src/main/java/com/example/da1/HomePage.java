package com.example.da1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class HomePage extends AppCompatActivity {

    ListView list;
    String titles[] = { "Degree", "Computer Programming Courses",
            "Programming Projects", "Courses", "Personal Information",
            "City"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        list = findViewById(R.id.list);
        ArrayAdapter<String> arr;
        arr = new ArrayAdapter<String>(
                this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                titles);
        list.setAdapter(arr);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        Intent intent = new Intent(HomePage.this, Degree.class);
                        intent.putExtra("title", "Degree");
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(HomePage.this, ComputerProgrammingCourses.class);
                        intent1.putExtra("title", "Programming Courses");
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(HomePage.this, ProgrammingProjects.class);
                        intent2.putExtra("title", "Programming Projects");
                        startActivity(intent2);
                        break;
                    case 3:
                        Intent intent3 = new Intent(HomePage.this, Courses.class);
                        intent3.putExtra("title", "Courses");
                        startActivity(intent3);
                        break;
                    case 4:
                        Intent intent4 = new Intent(HomePage.this, PersonalInformation.class);
                        intent4.putExtra("title", "Personal Information");
                        startActivity(intent4);
                        break;
                    case 5:
                        Intent intent5 = new Intent(HomePage.this, City.class);
                        intent5.putExtra("title", "City");
                        startActivity(intent5);
                        break;
                }
            }
        });
    }
}