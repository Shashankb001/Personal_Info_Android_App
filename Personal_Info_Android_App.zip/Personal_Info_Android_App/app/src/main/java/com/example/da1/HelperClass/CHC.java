package com.example.da1.HelperClass;

public class CHC {

    String course;
    String code;
    String year;

    public CHC(String course, String code, String year) {
        this.course = course;
        this.code = code;
        this.year = year;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
