package com.example.da1.HelperClass;

public class DegreeHC {
    String degree;
    String field;
    String institutions;

    public DegreeHC(String degree, String field, String institutions) {
        this.degree = degree;
        this.field = field;
        this.institutions = institutions;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getInstitutions() {
        return institutions;
    }

    public void setInstitutions(String institutions) {
        this.institutions = institutions;
    }
}
