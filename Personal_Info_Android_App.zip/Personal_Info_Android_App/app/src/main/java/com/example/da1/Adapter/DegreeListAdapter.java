package com.example.da1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.da1.HelperClass.DegreeHC;
import com.example.da1.R;

import java.util.ArrayList;

public class DegreeListAdapter extends ArrayAdapter<DegreeHC> {

    private Context mContext;
    int mResource;

    public DegreeListAdapter(Context context, int resource, ArrayList<DegreeHC> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String degree = getItem(position).getDegree();
        String field = getItem(position).getField();
        String institution = getItem(position).getInstitutions();

        DegreeHC degreeHC = new DegreeHC(degree, field, institution);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource, parent, false);

        TextView deg = (TextView) convertView.findViewById(R.id.degree_inp);
        TextView fld = (TextView) convertView.findViewById(R.id.field_inp);
        TextView inst = (TextView) convertView.findViewById(R.id.inst_inp);

        deg.setText(degree);
        fld.setText(field);
        inst.setText(institution);

        return convertView;
    }
}
