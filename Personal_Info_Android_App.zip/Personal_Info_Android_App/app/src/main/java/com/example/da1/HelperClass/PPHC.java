package com.example.da1.HelperClass;

public class PPHC {
    String title;
    String sub;
    String lang;
    String desc;

    public PPHC(String title, String sub, String lang, String desc) {
        this.title = title;
        this.sub = sub;
        this.lang = lang;
        this.desc = desc;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
