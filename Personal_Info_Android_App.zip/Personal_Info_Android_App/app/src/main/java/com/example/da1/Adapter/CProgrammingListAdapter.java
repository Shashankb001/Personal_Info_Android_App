package com.example.da1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.da1.HelperClass.CProgrammingHC;
import com.example.da1.HelperClass.DegreeHC;
import com.example.da1.R;

import java.util.ArrayList;

public class CProgrammingListAdapter extends ArrayAdapter<CProgrammingHC> {

    private Context mContext;
    int mResource;

    public CProgrammingListAdapter(Context context, int resource, ArrayList<CProgrammingHC> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String course = getItem(position).getCourse();
        String year = getItem(position).getYear();

        CProgrammingHC cphc = new CProgrammingHC(course, year);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource, parent, false);

        TextView c = (TextView) convertView.findViewById(R.id.course_inp);
        TextView y = (TextView) convertView.findViewById(R.id.year_inp);

        c.setText(course);
        y.setText(year);

        return convertView;
    }
}
