package com.example.da1.HelperClass;

public class CProgrammingHC {

    String course;
    String year;

    public CProgrammingHC(String course, String year) {
        this.course = course;
        this.year = year;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
