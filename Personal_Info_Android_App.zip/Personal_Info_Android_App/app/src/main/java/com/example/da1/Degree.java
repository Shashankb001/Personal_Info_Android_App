package com.example.da1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.da1.Adapter.DegreeListAdapter;
import com.example.da1.HelperClass.DegreeHC;

import java.util.ArrayList;

public class Degree extends AppCompatActivity {

    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_degree);

        //Getting title of the action bar
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");

        //Adding back button to action bar and setting title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(title);

        list = findViewById(R.id.list);

        DegreeHC vitc = new DegreeHC("Integrated MTech", "Software Engineering", "Vellore Institute of Technology, Chennai");
        DegreeHC twelth = new DegreeHC("Higher Secondary Education", "Maths(PCM)", "SNBP International School, Pimpri");
        DegreeHC tenth = new DegreeHC("Higher Education", "Schooling", "SNBP International School, Pimpri");


        ArrayList<DegreeHC> degreeList = new ArrayList<>();
        degreeList.add(vitc);
        degreeList.add(twelth);
        degreeList.add(tenth);

        DegreeListAdapter adp = new DegreeListAdapter(this, R.layout.degree_list, degreeList);
        list.setAdapter(adp);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}