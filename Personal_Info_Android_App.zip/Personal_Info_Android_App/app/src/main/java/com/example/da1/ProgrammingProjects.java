package com.example.da1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.da1.Adapter.DegreeListAdapter;
import com.example.da1.Adapter.PPListAdapter;
import com.example.da1.HelperClass.DegreeHC;
import com.example.da1.HelperClass.PPHC;

import java.util.ArrayList;

public class ProgrammingProjects extends AppCompatActivity {

    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programming_projects);

        //Getting title of the action bar
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");

        //Adding back button to action bar and setting title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(title);

        list = findViewById(R.id.listpp);

        PPHC p1 = new PPHC("House Price Prediction", "Data Mining", "Python", "Predicted House Price using AI & ML");
        PPHC p2 = new PPHC("Signature Forgery Detection", "DIP", "Python", "Distinguish b/w Fake and Real image");
        PPHC p3 = new PPHC("Stock Market Analysis", "AI", "Python", "Predicting Accuracy of Future Stock Prices");

        ArrayList<PPHC> ppList = new ArrayList<>();
        ppList.add(p1);
        ppList.add(p2);
        ppList.add(p3);

        PPListAdapter adp = new PPListAdapter(this, R.layout.pp_list, ppList);
        list.setAdapter(adp);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}