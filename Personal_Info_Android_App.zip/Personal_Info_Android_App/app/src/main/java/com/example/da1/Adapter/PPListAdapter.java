package com.example.da1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.da1.HelperClass.PPHC;
import com.example.da1.R;

import java.util.ArrayList;

public class PPListAdapter extends ArrayAdapter<PPHC> {

    private Context mContext;
    int mResource;

    public PPListAdapter(Context context, int resource, ArrayList<PPHC> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String title = getItem(position).getTitle();
        String sub = getItem(position).getSub();
        String lang = getItem(position).getLang();
        String desc = getItem(position).getDesc();

        PPHC pphc = new PPHC(title, sub, lang, desc);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource, parent, false);

        TextView t = (TextView) convertView.findViewById(R.id.title_inp);
        TextView s = (TextView) convertView.findViewById(R.id.sub_inp);
        TextView l = (TextView) convertView.findViewById(R.id.lang_inp);
        TextView d = (TextView) convertView.findViewById(R.id.desc_inp);

        t.setText(title);
        s.setText(sub);
        l.setText(lang);
        d.setText(desc);

        return convertView;
    }
}
