package com.example.da1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.da1.Adapter.CListAdapter;
import com.example.da1.Adapter.DegreeListAdapter;
import com.example.da1.HelperClass.CHC;
import com.example.da1.HelperClass.DegreeHC;

import java.util.ArrayList;

public class Courses extends AppCompatActivity {

    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        //Getting title of the action bar
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");

        //Adding back button to action bar and setting title
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(title);

        list = findViewById(R.id.listc);

        CHC c1 = new CHC("Digital Image Processing", "SWE1002", "3rd Year");
        CHC c2 = new CHC("OS", "SWE3001", "2nd Year");
        CHC c3 = new CHC("ISS", "SWE3002", "3rd Year");
        CHC c4 = new CHC("Computer Networks", "SWE2002", "2rd Year");
        CHC c5 = new CHC("DSA", "SWE2001", "2rd Year");


        ArrayList<CHC> cList = new ArrayList<>();
        cList.add(c1);
        cList.add(c2);
        cList.add(c3);
        cList.add(c4);
        cList.add(c5);

        CListAdapter adp = new CListAdapter(this, R.layout.c_list, cList);
        list.setAdapter(adp);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}